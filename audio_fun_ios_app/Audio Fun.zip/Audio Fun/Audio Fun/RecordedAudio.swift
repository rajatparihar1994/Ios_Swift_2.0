//
//  RecordedAudio.swift
//  Audio Fun
//
//  Created by acro on 11/6/15.
//  Copyright (c) 2015 dSlamBook. All rights reserved.
//

import Foundation

class RecordedAudio: NSObject {
   
    var filePathUrl: NSURL!
    var title: String!
    
}
